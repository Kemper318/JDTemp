Lab 103 - TA: Daniel Hoerauf
Team Name: JSONDerulo
Team Members: Alexandra Kemper (alk9zt), Priya Nakhre (pn2bh), Will Gorick (wig4da), Bryan Romback (bmr3ud), Alex Mangels (am8gv), Amanda Campos (ac8ek), Oliver Shi (oys4cv), Jeremy Wang (jhw2np) 
