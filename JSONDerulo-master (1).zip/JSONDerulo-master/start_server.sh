pushd JSONDockero
docker-compose up
popd
