pushd JSONDockero
docker-compose down
popd
